package Demo;


public class Main {
	private static Interfaz interfaz;
	
	public static void main(String[] args) {
		interfaz = new Interfaz();
	}
}
