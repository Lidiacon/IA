package Demo;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Panel;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

public class Interfaz extends JFrame{
	public Interfaz(){
		super("Ventana base");
		initGUI();
	}
	
	private void initGUI(){
		try{
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			setVisible(true);
			getContentPane().setLayout(new BorderLayout());
			//BorderLayout con ComboBox arriba para opciones y GridLayout en el centro
			//se muestran 2 columnas de 5 aplicaciones
			JPanel capaApps = new JPanel();
			
			JButton app = new JButton("APP");
			app.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
					String informacion = "Info de la app: \n Nombre: \n Tipo: \n Caracteristicas: \n";
					JOptionPane.showMessageDialog(null, informacion, "Informacion de la app", JOptionPane.INFORMATION_MESSAGE);
				}
			});
			app.setVisible(true);
			this.add(app);
		} catch (Exception e) {
            e.printStackTrace();
        }
	}
}
